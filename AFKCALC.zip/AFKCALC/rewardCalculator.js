let resultsVisible = false;

function calculate() {
    const s = parseInt(document.getElementById("secondsInput").value);
    const x = parseInt(document.getElementById("amountInput").value);
    const name = document.getElementById("nameInput").value || "reward";

    if (isNaN(s) || isNaN(x) || s <= 0 || x < 0) {
        alert("Please enter valid positive numbers for seconds and amount.");
        return;
    }

    // Disable input fields
    document.getElementById("secondsInput").disabled = true;
    document.getElementById("amountInput").disabled = true;
    document.getElementById("nameInput").disabled = true;
    document.getElementById("calculateButton").disabled = true;

    // Calculate hours, minutes, and seconds for `s`
    const hours = Math.floor(s / 3600);
    const minutes = Math.floor((s % 3600) / 60);
    const seconds = s % 60;

    // Display the time breakdown
    let results = `<p>It takes ${hours} hours, ${minutes} minutes, and ${seconds/x} seconds to get 1 ${name}.</p>`;

    // Reward calculation function
    function calculateRewards(intervalSeconds) {
        return Math.floor(intervalSeconds / s) * x;
    }

    // Time intervals in seconds
    const oneMinute = 60;
    const twentyMinutes = 20 * 60;
    const thirtyMinutes = 30 * 60;
    const oneHour = 60 * 60;

    // Add results for each interval
    results += `<p>You will get ${calculateRewards(oneMinute)} ${name} every 1 minute.</p>`;
    results += `<p>You will get ${calculateRewards(twentyMinutes)} ${name} every 20 minutes.</p>`;
    results += `<p>You will get ${calculateRewards(thirtyMinutes)} ${name} every 30 minutes.</p>`;
    results += `<p>You will get ${calculateRewards(oneHour)} ${name} every 1 hour.</p>`;

    // Output results
    const resultsDiv = document.getElementById("results");
    resultsDiv.innerHTML = results;
    resultsDiv.style.display = "block";  // Show results

    // Show the toggle button
    document.getElementById("toggleButton").style.display = "inline-block";

    // Hide input fields
    document.getElementById("inputFields").style.display = "none";
}

function toggleView() {
    const inputFields = document.getElementById("inputFields");
    const results = document.getElementById("results");
    
    if (resultsVisible) {
        // If results are currently visible, show input fields and hide results
        inputFields.style.display = "block";
        results.style.display = "none"; // Clear results
        resultsVisible = false;

        // Enable input fields
        document.getElementById("secondsInput").disabled = false;
        document.getElementById("amountInput").disabled = false;
        document.getElementById("nameInput").disabled = false;
        document.getElementById("calculateButton").disabled = false;

        // Hide toggle button
        document.getElementById("toggleButton").style.display = "none";
    } else {
        // If input fields are visible, hide them and show results
        inputFields.style.display = "none";
        resultsVisible = true;
    }
}
